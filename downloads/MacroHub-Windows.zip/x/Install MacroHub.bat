@echo off
setlocal
cd /d "%~dp0"

title MacroHub Installer
echo MacroHub Installer
echo ==================
echo.

set "ARCH=%PROCESSOR_ARCHITECTURE%"
if not "%PROCESSOR_ARCHITEW6432%"=="" set "ARCH=%PROCESSOR_ARCHITEW6432%"

set "COMPUTER_TYPE=Windows PC (%ARCH%)"
set "NODE_HINT=Windows Installer (.msi)"
if /i "%ARCH%"=="AMD64" set "NODE_HINT=Windows Installer (.msi) for x64"
if /i "%ARCH%"=="x86" set "NODE_HINT=Windows Installer (.msi) for x86"
if /i "%ARCH%"=="ARM64" set "NODE_HINT=Windows Installer (.msi) for ARM64"

echo Computer detected: %COMPUTER_TYPE%
echo.
echo Dependencies needed:
echo - Node.js: required to install and build MacroHub
echo - npm: included with the official Node.js installer
echo - AutoIt: required to run the included Windows fishing macro
echo.
echo Recommended official downloads:
echo - Node.js %NODE_HINT%
echo - https://nodejs.org/en/download
echo - AutoIt official download page
echo - https://www.autoitscript.com/site/autoit/downloads/
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required before MacroHub can be installed.
  echo Opening the official Node.js download page...
  start https://nodejs.org/en/download
  echo.
  echo Choose: %NODE_HINT%
  echo Install Node.js, then double-click this installer again.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo npm was not found. Reinstall Node.js from the official page and try again.
  start https://nodejs.org/en/download
  pause
  exit /b 1
)

for /f "tokens=*" %%v in ('node --version') do set "NODE_VERSION=%%v"
for /f "tokens=*" %%v in ('npm --version') do set "NPM_VERSION=%%v"
echo Node.js installed: %NODE_VERSION%
echo npm installed: %NPM_VERSION%
echo.

where AutoIt3.exe >nul 2>nul
if errorlevel 1 (
  echo AutoIt was not found.
  echo.
  echo MacroHub can still install, but the included Fishing script will not run until AutoIt is installed.
  echo Opening the official AutoIt download page...
  start https://www.autoitscript.com/site/autoit/downloads/
  echo.
  echo Install AutoIt, then you can use the Fishing script from MacroHub.
  echo.
) else (
  echo AutoIt installed: found AutoIt3.exe
  echo.
)

echo Installing MacroHub files...
call npm install
if errorlevel 1 (
  echo.
  echo Install failed.
  pause
  exit /b 1
)

echo.
echo Building the Windows app...
if exist "dist" rmdir /s /q "dist"
call npm run package:win
if errorlevel 1 (
  echo.
  echo Build failed.
  pause
  exit /b 1
)

echo.
echo MacroHub is installed.
echo.
echo Dependency check complete:
echo - Node.js: installed
echo - npm: installed
echo - AutoIt: needed for the included Fishing script
echo.
echo Installing MacroHub into your Windows apps folder...
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\MacroHub"
if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%"
mkdir "%INSTALL_DIR%"
xcopy /e /i /y "%cd%\dist" "%INSTALL_DIR%" >nul

set "START_MENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%START_MENU%\MacroHub.lnk'); $s.TargetPath='%INSTALL_DIR%\MacroHub.exe'; $s.WorkingDirectory='%INSTALL_DIR%'; $s.Save()"

reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\MacroHub" /v DisplayName /t REG_SZ /d "MacroHub" /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\MacroHub" /v DisplayVersion /t REG_SZ /d "1.0.0" /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\MacroHub" /v InstallLocation /t REG_SZ /d "%INSTALL_DIR%" /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\MacroHub" /v Publisher /t REG_SZ /d "MacroHub" /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\MacroHub" /v UninstallString /t REG_SZ /d "cmd /c rmdir /s /q \"%INSTALL_DIR%\" && del \"%START_MENU%\MacroHub.lnk\"" /f >nul

echo Opening MacroHub...
start "" "%INSTALL_DIR%\MacroHub.exe"
pause
